from flask import Flask, render_template, request, redirect, url_for, flash
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
import re
from datetime import datetime

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///community_hub.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)
migrate = Migrate(app, db)

# Import models
from models.activity_model import Activity
from models.registration_model import Registration
    
# Route for Homepage
@app.route("/")
def home():
    return render_template("home.html")  # Serve the homepage

@app.route('/how-to-use')
def how_to_use():
    return render_template('how_to_use.html')

@app.route('/explore-activities')
def explore_activities():
    # Fetch all activities from the database
    activities = Activity.query.all()
    return render_template('explore_activities.html', activities=activities)

@app.route('/talk-to-ai')
def talk_to_ai():
    # Logic for Talk to AI Assistant (placeholder)
    return "Talk to AI Assistant Page"

@app.route('/populate-activities')
def populate_activities():
    activities = [
        {
            "title": "Watercolor Painting Class",
            "description": "Unleash your creativity with a relaxing watercolor painting session, perfect for artists of all levels to explore vibrant colors and techniques",
            "location": "Art Studio Downtown",
            "time": "15th Nov, 10:00 AM",
            "image": "/static/images/painting.jpg",
            "benefits": "Reduce stress and anxiety, Boost creativity, Learn painting techniques",
            "testimonials": '"I discovered my inner artist!" - Alice, 55; "The session was so relaxing and fun!" - David, 62'
        },
        {
            "title": "Community Choir Practice",
            "description": "Join our harmonious choir sessions to connect with fellow music lovers and enjoy the joy of singing together in a warm community atmosphere",
            "location": "Community Hall",
            "time": "10th Nov, 6:00 PM",
            "image": "/static/images/choir.jpg",
            "benefits": "Improve vocal skills, Build community, Enhance confidence",
            "testimonials": '"I made lifelong friends here!" - John, 60; "Singing with others brings me so much joy!" - Mary, 67'
        },
        {
            "title": "Yoga Session",
            "description": "Experience rejuvenation and balance with our gentle yoga session, designed to reduce stress and enhance physical and mental well-being",
            "location": "City Park",
            "time": "20th Nov, 7:00 PM",
            "image": "/static/images/yoga.jpg",
            "benefits": "Increase flexibility and strength, Reduce stress and anxiety, Improve overall well-being",
            "testimonials": '"I feel more energetic and balanced after each session!" - Sarah, 45; "The best way to start my mornings!" - Michael, 52'
        },
        {
            "title": "Book Club",
            "description": "Dive into engaging discussions and connect with fellow readers in our welcoming book club, where we explore captivating stories together",
            "location": "City Park",
            "time": "20th Nov, 7:00 AM",
            "image": "/static/images/book.jpg",
            "benefits": "Stimulate intellectual curiosity, Foster meaningful discussions, Build a sense of community",
        "testimonials": '"I look forward to every meeting!" - Lisa, 48; "I have discovered so many great books through this club!" - Tom, 72'
        }
    ]

    for activity in activities:
        existing_activity = Activity.query.filter_by(title=activity["title"]).first()
        if not existing_activity:
            # Parse the human-readable time to a datetime object
            parsed_time = datetime.strptime(activity["time"], "%dth %b, %I:%M %p")
            new_activity = Activity(
                title=activity["title"],
                description=activity["description"],
                location=activity["location"],
                time=parsed_time,  # Use the parsed datetime object
                image=activity["image"],
                benefits=activity["benefits"],
                testimonials=activity["testimonials"]
            )
            db.session.add(new_activity)
    db.session.commit()
    return "Activities populated!"

@app.route('/delete-duplicates')
def delete_duplicates():
    activities = Activity.query.all()
    seen_titles = set()
    for activity in activities:
        if activity.title in seen_titles:
            db.session.delete(activity)
        else:
            seen_titles.add(activity.title)
    db.session.commit()
    return "Duplicates removed!"

@app.route('/activity/<int:id>')
def activity_detail(id):
    # Query the activity by its ID
    activity = Activity.query.get_or_404(id)
    return render_template('activity_detail.html', activity=activity)


@app.template_filter('datetimeformat')
def datetimeformat(value, format='%d %b, %Y %I:%M %p'):
    """Format a datetime object for display."""
    if isinstance(value, datetime):
        return value.strftime(format)
    if isinstance(value, str):
        # Parse the string and default to 2024 if no year is provided
        try:
            dt = datetime.strptime(value, "%dth %b, %I:%M %p")
            return dt.replace(year=2024).strftime(format)  # Default year to 2024
        except ValueError:
            return value  # Return as-is if parsing fails
    return value  # Return as-is if the value is not recognized

@app.route('/register/<int:activity_id>', methods=['GET', 'POST'])
def register(activity_id):
    # Fetch the activity details for context
    activity = Activity.query.get_or_404(activity_id)

    if request.method == 'POST':
        # Extract form data
        name = request.form.get('name')
        contact_info = request.form.get('contact_info')
        preferred_time = request.form.get('preferred_time')
        special_needs = request.form.get('special_needs')

        # Validation logic
        if not name.isalpha():
            flash("Name must only contain letters. Please try again.", "error")
            return render_template('registration_form.html', activity=activity)

        if not contact_info.isdigit():
            flash("Contact information must only contain numbers. Please try again.", "error")
            return render_template('registration_form.html', activity=activity)

        # Save the registration to the database
        new_registration = Registration(
            activity_id=activity.id,
            name=name,
            contact_info=contact_info,
            preferred_time=preferred_time,
            special_needs=special_needs
        )
        db.session.add(new_registration)
        db.session.commit()

        return redirect(url_for('register_success'))

    return render_template('registration_form.html', activity=activity)

@app.route('/register-success')
def register_success():
    return render_template('register_success.html')
    
@app.route('/my-registrations')
def my_registrations():
    registrations = Registration.query.all()  # Fetch all registrations from the database
    return render_template('my_registrations.html', registrations=registrations)

@app.route('/delete-registration/<int:registration_id>', methods=['POST'])
def delete_registration(registration_id):
    # Query the registration by ID
    registration = Registration.query.get_or_404(registration_id)
    
    # Delete the registration from the database
    db.session.delete(registration)
    db.session.commit()
    
    # Redirect back to the My Registrations page
    return redirect(url_for('my_registrations'))


if __name__ == '__main__':
    app.run(debug=True)
